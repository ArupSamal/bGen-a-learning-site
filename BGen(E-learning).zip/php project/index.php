<?php
header('location:landing/index.php');
?>