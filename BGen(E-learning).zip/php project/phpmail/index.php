
<?php
$message=$_GET["msg"];
$em=$_GET["mail"];
$sub=$_GET["sub"];
$loc=$_GET["gbt"];
echo $loc;

        require "phpmailer/class.phpmailer.php";
        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = "ssl";
        $mail->Host = "smtp.gmail.com";
        $mail->Port = 465;
        $mail->Encoding = '7bit';
        $mail->Username   = "bgen.kamlesh@gmail.com";
        $mail->Password   = "bgenadmin";
        $mail->SetFrom("bgen.kamlesh@gmail.com");
        //$mail->AddReplyTo("$em");
        $mail->Subject = $sub;
        $mail->MsgHTML($message);
        $mail->AddAddress("$em");
        $result = $mail->Send();
        unset($mail);
        if($result)
        {
          echo "<script>alert('Password sent to your email ID ');
          </script>";
          header('location:'.$loc);

        }
        else
          {
            echo "<script>alert('Error! Please try again later.');
          </script>";
          }
?>