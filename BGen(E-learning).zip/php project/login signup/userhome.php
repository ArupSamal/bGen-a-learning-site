<?php 
session_start();
if(isset($_SESSION["first_name"]))
$first_name = $_SESSION["first_name"];
 ?>
 WELCOME
 <?php 
echo $first_name;
  ?>
  <a href="logout.php">logout</a>
