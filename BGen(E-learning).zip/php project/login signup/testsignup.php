<?php 
session_start();
if(isset($_SESSION["first_name"]))
{
$first_name = $_SESSION["first_name"];
 echo "WELCOME";
echo $first_name;
echo "&nbsp you are at homepage";
}
  ?>

  <a href="logout.php">logout</a>
