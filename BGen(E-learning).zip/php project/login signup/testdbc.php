<?php 
session_start();
if(isset($_REQUEST["signup"]))
{
	include "connectdb.php";
	$type=$_REQUEST["type"];
	$first_name=$_REQUEST["first_name"];
	$last_name=$_REQUEST["last_name"];
	$email=$_REQUEST["email"];
	$password=$_REQUEST["password"];
	if($type=='student')
	{
	mysqli_query($con,"INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `password`, `type`) VALUES (NULL, '$first_name', '$last_name', '$email', '$password', '$type');");

	$res=mysqli_query($con,"select * from users where email='$email'");
	if($arr=mysqli_fetch_assoc($res))
	{

		$_SESSION["first_name"]=$arr["firstname"];
		$_SESSION["type"]=$arr["type"];
		header('location:../landing/index.php');
	}
	}
	if($type=='expert')
	{
		$profession=$_REQUEST["profession"];
		$at=$_REQUEST["at"];
	mysqli_query($con,"INSERT INTO `pending` (`id`, `firstname`, `lastname`, `email`, `password`, `type`, `profession`, `at`) VALUES (NULL, '$first_name', '$last_name', '$email', '$password', 'expert', '$profession', '$at');");
header('location:../landing/index.php');

	/*$res=mysqli_query($con,"select * from users where email='$email'");
	if($arr=mysqli_fetch_assoc($res))
	{

		$_SESSION["first_name"]=$arr["first_name"];
		header('location:testsignup.php');
	}*/
	}


}

if(isset($_REQUEST["login"]))
{
	include "connectdb.php";
	$email=$_REQUEST["email"];
	$password=$_REQUEST["password"];
	//$pass=sha1($pass);
	$result=mysqli_query($con,"select * from users where email='$email' and password='$password'");

	if($arr=mysqli_fetch_assoc($result))
	{
		$_SESSION["first_name"]=$arr["firstname"];
		$_SESSION["type"]=$arr["type"];
		$typ=$arr["type"];
		if ($typ=="admin") {
			header('location:../admin/admin.php');
			# code...
		}
		if ($typ=="expert") {
			header('location:../admin/expert.php');
			# code...
		}
		if ($typ=="student") {
			header('location:../landing/index.php');
			# code...
		}


	}
	else{
		
		header('location:failed.php');
	}

}


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>login /signup</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="lgin.css">
<link rel="stylesheet" href="style.css">
<link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
<body >
	<div class="bg">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4 col-sm-4 col-xs-4"></div>
			<div class="col-md-4 col-sm-4 col-xs-4">
				<form class="form-container" name="myForm">
				<ul class="tab-group">
        			<li class="tab active"><a href="#signup">Sign Up</a></li>
        			<li class="tab "><a href="#login">Log In</a></li>
      			</ul>
      
		      		<div class="tab-content">
							        	<div id="signup">   
					          <h1>Sign Up for Free</h1>
					          
					          <form method="GET">
					          
					          <div class="top-row" style="margin-top: -20px;">
					            <div class="field-wrap">
					              <input type="text" required autocomplete="off" name="first_name" placeholder="First Name *" />
					            </div>
					        
					            <div class="field-wrap">
					            
					              <input type="text" required placeholder="Last Name *" name="last_name" autocomplete="off"/>
					            </div>
					          </div>

					          <div class="field-wrap"  >
					           
					            <input type="text" required autocomplete="off" id="email" name="email" placeholder="Email *"  />
					            <script>
  document.getElementById("email").addEventListener("change", validateForm);
function validateForm() {
    var x = document.forms["myForm"]["email"].value;
    var atpos = x.indexOf("@");
    var dotpos = x.lastIndexOf(".");
    if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
        alert("Not a valid e-mail address");
        return false;
    }
}
</script>
					          </div>
					          
					          <div class="field-wrap" style="margin-top: -5px;">
					           
					            <input type="password" required autocomplete="off" name="password" placeholder="Set a Password *" />

					          </div>
					        

					          <table width="80%" style="margin-top: -20px; margin-left: 20px" >
					          	<td><input type="radio" name="type" value="student" checked onclick="document.getElementById('profession').type='hidden';
               document.getElementById('at').type='hidden';" style="height: 17px;width: 17px;"></td>
					          	<td><p style="color: aqua; text-align:left; font-size: 20px"><b>student</b></p></td>
					          	<td><input type="radio" name="type" value="expert" onclick="document.getElementById('profession').type='text';
               document.getElementById('at').type='text';" style="height: 17px;width: 17px; "></td>
					          	<td><p style="color: aqua; text-align:left; font-size: 20px"><b>expert</b></p></td>
					          </table>

					          <div class="field-wrap" >
					           
					            <input type="hidden" required id="profession" autocomplete="off" name="profession" placeholder="working as" style="height: 40px;margin-top: 3px;" />
					        <br>
					             <input type="hidden" required id="at" autocomplete="off" name="at" placeholder="AT" style="height: 40px;margin-top: -3px; margin-bottom: 50px;" />


					          </div>
					          
					          
					          <input type="submit" class="button button-block" name="signup" value="GET STARTED" style="margin-top: -30px" />
					          
					          </form>

					        </div>
					        <div id="login">   
          <h1>Welcome Back!</h1>
          
          <form method="GET">
          
            <div class="field-wrap">
       
            <input type="email" required autocomplete="off" name="email" placeholder="Email Address *"/>
          </div>
          
          <div class="field-wrap">
            
            <input id="passs" type="password" required autocomplete="off" name="password" placeholder="Password *" />
            <table>
            	<tr>
            		<td><input type="checkbox" name="show_pass" value="show_pass" id="show_pass" onclick="showpass()" style="height: 15px;width: 15px; " ></td>
            		<td>show password</td>
            	</tr>
            </table>

          
          </div>
          
          <p class="forgot"><a href="forgotpass.php"><b>Forgot Password?</b>></a></p>
          
          <button type="submit" class="button button-block" name="login" />Log In</button>
          
          </form>

        </div>
		          	</div>
				</form>          


			</div>
		</div>
	</div>
	</div>

  
	<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script  src="js/index.js"></script>
    <script>
function showpass() 
{
    var x = document.getElementById("passs");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
</script>

</body>	
</html>


