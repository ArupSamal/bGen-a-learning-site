<?php
if(isset($_REQUEST["getpass"]))
{
	$email=$_REQUEST["mail"];
	include "connectdb.php";
	$result=mysqli_query($con,"select * from users where email='$email'");
	$arr=mysqli_fetch_assoc($result);
	$pass=$arr["password"];
	$msg="your password for bgen is ".$pass;
	$sub="Password for bgen";
	$gbt="../login signup/testdbc.php";


	$location='../phpmail/index.php?mail='.$email.'&msg='.$msg.'&sub='.$sub.'&gbt='.$gbt;
	header('location:'.$location);
	
	
}
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>login /signup</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="lgin.css">
<link rel="stylesheet" href="style.css">
<link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
<body >
	<div class="bg">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4 col-sm-4 col-xs-4"></div>
			<div class="col-md-4 col-sm-4 col-xs-4">
				<form class="form-container" name="myForm" style="margin-top: 140px;">
					<h1>Forgot Password</h1>
					<div class="field-wrap">
					<input type="text" name="mail" placeholder="Email *" required="required">
				    </div>
					<button type="submit" class="button button-block" name="getpass" onclick="test();">GET PASSWORD</button>
				</form>
			</div>
		</div>
	</div>
</div>

  
	<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script  src="js/index.js"></script>
    <script>
    	function test() {
    	    alert("A mail will be send to you with your Password ");
    	    } 
    </script>
    

</body>	
</html>


