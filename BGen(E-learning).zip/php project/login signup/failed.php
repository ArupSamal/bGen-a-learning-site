<!DOCTYPE html>
<html>
<head>
	<title>failed login</title>
	<meta charset="utf-8">
	<meta http-equiv="refresh" content="2;URL='testdbc.php'">
</head>
<body>
<h1>the email and password did not matched our db</h1>
</body>
</html>