<?php
session_start();
include "connectdb.php";

$handle = fopen("../admin/counter.txt", "r");
if(!$handle){
 echo "could not open the file" ;
}
else {
    $counter = ( int ) fread ($handle,20) ;
    fclose ($handle) ;
    $counter++ ;
$handle =  fopen("../admin/counter.txt", "w" ) ;
fwrite($handle,$counter) ;
fclose ($handle) ;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>bGen</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="main.css">
<link rel="stylesheet" type="text/css" href="test.css">

  <!--
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  !--><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
.overlay {
    height: 0%;
    width: 100%;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: rgb(0,0,0);
    background-color: rgba(0,0,0, 0.9);
    overflow-y: hidden;
    transition: 0.5s;
}

.overlay-content {
    position: relative;
    /*top: 15%;*/
    width: 100%;
    text-align: center;
    margin-top: 30px;
}

.overlay a {
    padding: 8px;
    text-decoration: none;
    font-size: 36px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.overlay a:hover, .overlay a:focus {
    color: #f1f1f1;
}

.overlay .closebtn {
    position: absolute;
    top: 20px;
    right: 45px;
    font-size: 60px;
}

@media screen {
  .overlay {overflow-y: scroll;}
  .overlay a {font-size: 20px}
  .overlay .closebtn {
    font-size: 40px;
    top: 15px;
    right: 35px;
  }
}
.clear { /* Also commonly known as clearfix */
clear: both; /* At the very least, you must have this. All extra declarations are for fine-tuning */
height: 0;
font-size: 0;
overflow: hidden;
margin: 0;
padding: 0;
width: 0;
line-height: 0;
}

div.containers {
margin: 0 auto; /* This will center a fixed-width container */
width: 80%;
}
div.items {
float: left;
width: 250px;
overflow: hidden;
margin: 5px;
}
</style>
</head>
<body>
  <div id="myNav" class="overlay">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <div class="overlay-content">
    <div style="margin-top: 9%;" id="maj" >
    <table border="0px" align="center" width="70%">
      <tr style="height: 30px;">
        <td colspan="2" align="left" style="color: white; font-family:Palatino; font-size: 50px;"> Choose a Stream...</td>
      </tr>
      <tr>
        <td align="center">
          <a href="#" onclick="eng();">
            <div style="height: 130px;width: 270px;border-color: black; background-color: black; margin-bottom: 25px; border-radius: 15px 50px; background-image: url(engineering.jpg); opacity: 0.7;">
        <h1 style="color: white; padding-top: 40px;" align="center">Engineering</h1>        
      </div>
          </a>
        </td>
        <td align="center">
          <a href="#" onclick="med();">
          <div style="height: 130px;width: 270px;border-color: black; background-color: black; margin-bottom: 25px; border-radius: 15px 50px; background-image: url(medical.jpg); opacity: 0.7;">
        <h1 style="color: white; padding-top: 40px;" align="center">Medical</h1>        
      </div>
    </a>
        </td>
      </tr>
      <tr>
        <td align="center">
          <a href="#" onclick="laww();">
          <div style="height: 130px;width: 270px;border-color: black; background-color: black; margin-bottom: 25px; border-radius: 15px 50px; background-image: url(law.jpg); opacity: 0.7;">
        <h1 style="color: white; padding-top: 40px;" align="center">Law</h1>        
      </div>
    </a>
        </td>
        <td align="center">
          <a href="#" onclick="bm()">
          <div style="height: 130px;width: 270px;border-color: black; background-color: black; margin-bottom: 25px; border-radius: 15px 50px; background-image: url(business.jpg); opacity: 0.7;">
        <h1 style="color: white; padding-top: 40px;" align="center">Business and Marketing</h1>        
      </div>
    </a>
        </td>
      </tr>
    </table>
    </div>

<div id="eng" hidden style="margin-top: 5%">
  <h1 style="color: white">Engineering->select subject</h1>
<div class="containers" >
<?php
$find=mysqli_query($con,"SELECT DISTINCT `branch` FROM `subject` WHERE major ='engineering'");
                     while($row=mysqli_fetch_array($find))
                     {
                      $br=$row['branch'];
                      echo '<div class="items" style="background-color: white;border-radius: 15px;">
  <div  style="background-color: skyblue"><b>'.$br.'</b></div>';
                      
                      $find1=mysqli_query($con,"SELECT DISTINCT `subject` FROM `subject` WHERE branch ='$br'");
                      while($row1=mysqli_fetch_array($find1))
                     {
                      $sub=$row1['subject'];
                      $find5=mysqli_query($con,"SELECT DISTINCT `topic` FROM `subject` WHERE subject ='$sub'");
                      $row5=mysqli_fetch_array($find5);
                      $tpic=$row5['topic'];


                      echo '<div align="left" style="padding-left: 15px; margin-top:-5px;">
<a href="../result/index.php?search-item='.$tpic.'&search=sh""><li>'.$sub.'</li></a>
</div>';
                     }
                     echo '<div class="clear"></div>
</div>';
                     }

?>
</div>

  

  
  
</div>
<div id="med" hidden style="margin-top: 5%">
  <h1 style="color: white">medical->select subject</h1>

  <div class="containers" >
<?php
$find=mysqli_query($con,"SELECT DISTINCT `branch` FROM `subject` WHERE major ='medical'");
                     while($row=mysqli_fetch_array($find))
                     {
                      $br=$row['branch'];
                      echo '<div class="items" style="background-color: white;border-radius: 15px;">
  <div  style="background-color: skyblue"><b>'.$br.'</b></div>';
                      
                      $find1=mysqli_query($con,"SELECT DISTINCT `subject` FROM `subject` WHERE branch ='$br'");
                      while($row1=mysqli_fetch_array($find1))
                     {
                      $sub=$row1['subject'];
                      echo '<div align="left" style="padding-left: 15px; margin-top:-5px;">
<a href=""><li>'.$sub.'</li></a>
</div>';
                     }
                     echo '<div class="clear"></div>
</div>';
                     }

?>
</div>
  
</div>
<div id="laww" hidden style="margin-top: 5%">
  <h1 style="color: white">law->select subject</h1>
  
<div class="containers" >
<?php
$find=mysqli_query($con,"SELECT DISTINCT `branch` FROM `subject` WHERE major ='law'");
                     while($row=mysqli_fetch_array($find))
                     {
                      $br=$row['branch'];
                      echo '<div class="items" style="background-color: white;border-radius: 15px;">
  <div  style="background-color: skyblue"><b>'.$br.'</b></div>';
                      
                      $find1=mysqli_query($con,"SELECT DISTINCT `subject` FROM `subject` WHERE branch ='$br'");
                      while($row1=mysqli_fetch_array($find1))
                     {
                      $sub=$row1['subject'];
                      echo '<div align="left" style="padding-left: 15px; margin-top:-5px;">
<a href=""><li>'.$sub.'</li></a>
</div>';
                     }
                     echo '<div class="clear"></div>
</div>';
                     }

?>
</div>

</div>
<div id="bm" hidden style="margin-top: 5%">
  <h1 style="color: white">business and marketing->select subject</h1>
  
  <div class="containers" >
<?php
$find=mysqli_query($con,"SELECT DISTINCT `branch` FROM `subject` WHERE major ='business'");
                     while($row=mysqli_fetch_array($find))
                     {
                      $br=$row['branch'];
                      echo '<div class="items" style="background-color: white;border-radius: 15px;">
  <div  style="background-color: skyblue"><b>'.$br.'</b></div>';
                      
                      $find1=mysqli_query($con,"SELECT DISTINCT `subject` FROM `subject` WHERE branch ='$br'");
                      while($row1=mysqli_fetch_array($find1))
                     {
                      $sub=$row1['subject'];
                      echo '<div align="left" style="padding-left: 15px; margin-top:-5px;">
<a href=""><li>'.$sub.'</li></a>
</div>';
                     }
                     echo '<div class="clear"></div>
</div>';
                     }

?>
</div>

</div>


  </div>
</div>

  <nav class="navbar navbar-inverse">
  <div class="container-fluid" >
    <div class="navbar-header" >
      
      <a  href="index.php"><img src="bgen.png" height=43 width="130" style="margin-right: 20px;" ></a>
    </div>
    <ul class="nav navbar-nav">

      <li class="active"><a href="#">Home</a></li>
      
     
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <?php
      if(isset($_SESSION["type"]))
        {
          $typ=$_SESSION["type"];
          if ($typ=="admin") {
            echo '<li> <a href="../admin/admin.php">
          <span class="glyphicon glyphicon glyphicon-cog"></span>Admin panel
        </a></li>';
            # code...
          }
          if ($typ=="expert") {
            echo '<li> <a href="../admin/expert.php">
          <span class="glyphicon glyphicon glyphicon-cog"></span>Expert panel
        </a></li>';
            # code...
          }
          
        }
       ?>
     <li><a href="#" >About us  </a></li>
      <li ><a href="#" >contact us</a></li>
      <?php 
      if(isset($_SESSION["first_name"]))
        {
          $f_name=$_SESSION["first_name"];
        echo  '<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">welcome '.$f_name.'&nbsp&nbsp  <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li> <a href="logout.php">
          <span class="glyphicon glyphicon glyphicon-off"></span>&nbsplogout&nbsp&nbsp
        </a></li>
        </ul> ';
          
        }
        else
        {

          echo '<li><a href="../login signup/testdbc.php"><span class="glyphicon glyphicon-user" ></span> Sign Up/login&nbsp&nbsp</a></li>';
        }
      ?>
      
    </ul>
  </nav>
</header>
  <img src="stdp/1.jpeg" height="450px" width="99%" style="margin-left: 7px;">

  <form class="col-sm-12" id="searchForm" action="../result/index.php" method="post" >
    <div class="form-group col-sm-6 col-sm-offset-3">
    	<div class="input-group">
      <input id="search" type="text" class="form-control" name="search-item" placeholder="Search a topic ..." style="height: 50px;width: 500px;">

      <button type="submit" name="search" style="height: 50px; " ><span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span></button>   

    </div>
    <center><a href="#" class="btn btn-info btn-lg" style="margin-top: 15px; background-color: #0066CC;" onclick="openNav()">
          <span class="glyphicon glyphicon-align-justify"></span> Browse Cources
        </a></center>
     
    </div>
  </form>
<hr>
  <h2>Most Popular Subjects</h2>
  <hr >
  <table width="97%" border="0px" style="margin-left: 30px; ">
    <tr>
      <td><div style="height: 120px;width: 250px;border-color: aqua; background-color: aqua; margin-bottom: 25px; border-radius: 15px 50px; background-image: url(p.jpg); opacity: 0.8;">
        <h1 style="color: white; padding-top: 40px;" align="center">c++</h1>        
      </div></td>
      <td><div style="height: 120px;width: 250px;border-color: aqua; background-color: aqua; margin-bottom: 25px; border-radius: 15px 50px; background-image: url(pc.jpg); opacity: 0.8;">
        <h1 style="color: white; padding-top: 40px;" align="center">java</h1>        
      </div></td>
      <td><div style="height: 120px;width: 250px;border-color: aqua; background-color: aqua; margin-bottom: 25px; border-radius: 15px 50px; background-image: url(p.jpg); opacity: 0.8;">
        <h1 style="color: white; padding-top: 40px;" align="center">html</h1>        
      </div></td>
      <td><div style="height: 120px;width: 250px;border-color: aqua; background-color: aqua; margin-bottom: 25px; border-radius: 15px 50px; background-image: url(p3.jpg); opacity: 0.8;">
        <h1 style="color: white; padding-top: 40px;" align="center">css</h1>        
      </div></td>
      
    </tr>
   <tr>
    <td><div style="height: 120px;width: 250px;border-color: aqua; background-color: aqua; margin-bottom: 25px; border-radius: 15px 50px; background-image: url(pc.jpg); opacity: 0.8;">
        <h1 style="color: white; padding-top: 40px;" align="center">javascript</h1>        
      </div></td>
      <td><div style="height: 120px;width: 250px;border-color: aqua; background-color: aqua; margin-bottom: 25px; border-radius: 15px 50px; background-image: url(p3.jpg); opacity: 0.8;">
        <h1 style="color: white; padding-top: 40px;" align="center">ajax</h1>        
      </div></td>
      <td><div style="height: 120px;width: 250px;border-color: aqua; background-color: aqua; margin-bottom: 25px; border-radius: 15px 50px; background-image: url(pc.jpg); opacity: 0.8;">
        <h1 style="color: white; padding-top: 40px;" align="center">jquery</h1>        
      </div></td>
      <td><div style=" height: 120px;width: 250px;border-color: aqua; background-color: aqua; margin-bottom: 25px; border-radius: 15px 50px; background-image: url(p.jpg); opacity: 0.8;">
        <h1 style="color: white; padding-top: 40px;" align="center">bootstrap</h1>        
      </div></td>
      
    </tr>
  </table>
  <script type="text/javascript">
function openNav() {
    document.getElementById("myNav").style.height = "100%";
}

function closeNav() {
    document.getElementById("myNav").style.height = "0%";
    document.getElementById("maj").hidden = "";
    document.getElementById("eng").hidden = "hidden";
    document.getElementById("med").hidden = "hidden";
    document.getElementById("laww").hidden = "hidden";
    document.getElementById("bm").hidden = "hidden";

}
function eng() {

document.getElementById("maj").hidden = "hidden";
document.getElementById("eng").hidden = "";
}
function med() {

document.getElementById("maj").hidden = "hidden";
document.getElementById("med").hidden = "";
}
function laww() {

document.getElementById("maj").hidden = "hidden";
document.getElementById("laww").hidden = "";
}
function bm() {

document.getElementById("maj").hidden = "hidden";
document.getElementById("bm").hidden = "";
}
</script>

</body>
<footer style="width: 100%; background-color: black;color: white; height: 100px; margin-top: 150px;">
  <div>
    
  </div>
</footer>
</html>
  