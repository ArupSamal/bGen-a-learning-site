<?php
	include_once('connectdb.php');
 $db = $_GET['db'];

	if( isset($_GET['del']) && $db=="pending_ques" )
	{
		$ques = $_GET['del'];
		$sql= "DELETE FROM `pending_ques` WHERE `question`= '$ques'";
		$res= mysqli_query($con,$sql) or die("Failed".mysqli_error());
		echo "<meta http-equiv='refresh' content='0;url=admin.php'>";
	}
	if( isset($_GET['add']) && $db=="pending_ques" )
	{

		$ques = $_GET['add'];
		$result=mysqli_query($con,"SELECT * FROM `pending_ques` WHERE `question`='$ques'");
		$arr=mysqli_fetch_assoc($result);
        $op1= $arr["op1"];
      
        $op2=$arr["op2"];
       
        $op3=$arr["op3"];

        $cor=$arr["correct"];

		$sql= "INSERT INTO `question` (`id`, `question`, `op1`, `op2`, `op3`, `correct`) VALUES (NULL, '$ques', '$op1', '$op2', '$op3', '$cor')";
		$res= mysqli_query($con,$sql) or die("Failed".mysqli_error());
		$sql1= "DELETE FROM `pending_ques` WHERE `question`= '$ques'";
		$res1= mysqli_query($con,$sql1) or die("Failed".mysqli_error());
		echo "<meta http-equiv='refresh' content='0;url=admin.php'>";
	
		
	}
?>
