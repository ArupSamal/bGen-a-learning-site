<?php
	include_once('connectdb.php');
 $db = $_GET['db'];

	if( isset($_GET['del']) && $db=="users" )
	{
		$email = $_GET['del'];
		$sql= "DELETE FROM `users` WHERE `email`= '$email'";
		$res= mysqli_query($con,$sql) or die("Failed".mysqli_error());
		$msg="your account in bgen is revoked";
		$sub="account revoked";
		$gbt="../admin/admin.php";

		$location='../phpmail/index.php?mail='.$email.'&msg='.$msg.'&sub='.$sub.'&gbt='.$gbt;
		header('location:'.$location);
	}
	if( isset($_GET['del']) && $db=="pending" )
	{
		$email = $_GET['del'];
		$sql= "DELETE FROM `pending` WHERE `email`= '$email'";
		$res= mysqli_query($con,$sql) or die("Failed".mysqli_error());

		$msg="you were not accepted as expert in bgen";
		$sub="account revoked";
		$gbt="../admin/admin.php";
		$location='../phpmail/index.php?mail='.$email.'&msg='.$msg.'&sub='.$sub.'&gbt='.$gbt;
		header('location:'.$location);

	}
	if( isset($_GET['add']) && $db=="pending" )
	{
		$email = $_GET['add'];
		$result=mysqli_query($con,"SELECT * FROM `pending` WHERE `email`='$email'");
		$arr=mysqli_fetch_assoc($result);
        $firstname=$arr["firstname"];
       // echo $firstname;
        $lastname=$arr["lastname"];
        $email=$arr["email"];
        $password=$arr["password"];
        $type=$arr["type"];

		$sql= " INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `password`, `type`) VALUES (NULL, '$firstname', '$lastname', '$email', '$password', 'expert')";
		$res= mysqli_query($con,$sql) or die("Failed".mysqli_error());
		$sql1= "DELETE FROM `pending` WHERE `email`= '$email'";
		$res1= mysqli_query($con,$sql1) or die("Failed".mysqli_error());
		
		$msg="congratulation, you are now an expert in bgen";
		$sub="welcome expert ";
		$gbt="../admin/admin.php";
		$location='../phpmail/index.php?mail='.$email.'&msg='.$msg.'&sub='.$sub.'&gbt='.$gbt;
		header('location:'.$location);

	}
?>
