<?php
$con=mysqli_connect('localhost','root','','project');
if (!$con) {
	die("failed");
			}
if(isset($_POST['get_major']))
{
 $major = $_POST['get_major'];
 echo "<option hidden selected >select branch</option>";
 $find=mysqli_query($con,"SELECT DISTINCT `branch` FROM `subject` WHERE `major`='$major'");
 while($row=mysqli_fetch_array($find))
 {
  echo "<option>".$row['branch']."</option>";

 }
 exit;
}
if(isset($_POST['get_branch']))
{
 $branch = $_POST['get_branch'];
 echo "<option hidden selected >select subject</option>";
 $find=mysqli_query($con,"SELECT DISTINCT `subject` FROM `subject` WHERE `branch`='$branch'");
 while($row=mysqli_fetch_array($find))
 {
  echo "<option>".$row['subject']."</option>";

 }
 exit;
}

if(isset($_POST['get_subject']))
{

 $subject = $_POST['get_subject'];
 echo "<option hidden selected >select topic</option>";
 $find=mysqli_query($con,"SELECT DISTINCT `topic` FROM `subject` WHERE `subject`='$subject'");
 while($row=mysqli_fetch_array($find))
 {
  echo "<option>".$row['topic']."</option>";

 }
 exit;
}

if(isset($_POST['get_topic']))
{
	

 $topic = $_POST['get_topic'];
 echo "<option hidden selected >select notes</option>";
 $find=mysqli_query($con,"SELECT DISTINCT `notes` FROM `notes` WHERE `topic`='$topic'");
 while($row=mysqli_fetch_array($find))
 {
  echo '<option style="width: 94%">'.$row['notes'].'</option>';

 }
 exit;
}

if(isset($_POST['get_vtopic']))
{


 $vtopic = $_POST['get_vtopic'];
 echo "<option hidden selected >select name</option>";
 $find=mysqli_query($con,"SELECT DISTINCT `name` FROM `videos` WHERE `topic`='$vtopic'");
 while($row=mysqli_fetch_array($find))
 {
  echo "<option>".$row['name']."</option>";

 }
 exit;
}




if(isset($_POST['get_top_ex']))
{

echo "<option>test</option>";
 $vtopicex = $_POST['get_top_ex'];
 $find=mysqli_query($con,"SELECT DISTINCT `question` FROM `examples` WHERE `topic`='$vtopicex'");
 while($row=mysqli_fetch_array($find))
 {
  echo "<option>".$row['question']."</option>";

 }
 exit;
}

if(isset($_POST['get_quiz_ques']))
{

echo "<option>test</option>";
 $topicqz = $_POST['get_quiz_ques'];
 $find=mysqli_query($con,"SELECT DISTINCT `question` FROM `quiz` WHERE `topic`='$topicqz'");
 while($row=mysqli_fetch_array($find))
 {
  echo "<option>".$row['question']."</option>";

 }
 exit;
}


?>
