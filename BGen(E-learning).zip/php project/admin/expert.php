<?php
session_start();
if (isset($_SESSION["type"]))
 {
    $x=$_SESSION["type"];
    if ($_SESSION["type"]!=="expert")
     {
        header('location:../landing/index.php');
    
        # code...
    }
    
 } 
 else
 {
    header('location:../landing/index.php');
 }
 ?>
<!DOCTYPE html>
<html>
<head>
    <title>expert</title>
    <link rel="stylesheet" type="text/css" href="admincss.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <style type="text/css">
        select{
        height: 25px; width: 23%;}
    </style>


</head>
<body>

<div class="admin-panel">
  
    <div class="slidebar" style=" height: 100%;
    width: 160px;
    position: fixed; height: 100%;
    width: 160px;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;">
        <ul>
            <li><a href="" name="tab1"><i class="fa fa-tachometer"></i>General</a></li>
            <li><a href="" name="tab4"><i class="fa fa-sticky-note"></i>Add Notes</a></li>
            <li><a href="" name="tab5"><i class="fa fa-file-video-o"></i>Add Aideos</a></li>
            <li><a href="" name="tab6"><i class="fa fa-code"></i>Add Q&A</a></li>
        </ul>
    </div>
  
    <div class="main" style="width: 100%">
         <div id="tab1"><h2 class="header">Dashboard</h2> 
            <table border="1px" style="border-collapse: collapse;margin-left: 20px; margin-right: 20px;margin-bottom: 40px;" width="95%">
                <tr>
                    <td colspan="4" width="50%"><center><a href="../landing/index.php"><img src="home.png" style="height: 120px;width: 120px;"></a></center></td>
                    <td rowspan="5" align="center">
                        <table border="0px" style=" margin-bottom:30px; margin-left: 12px;margin-right: 15px " width="100%" >
                            
                            <tr>
                                <td colspan="6"><h2 align="center" >ADD</h2></td>
                                </tr>
                                <tr>
                                <td><input type="radio" name="to-add" checked id="add-topic" value="add-topic" onclick="hide()" ></td>
                                <td>Topic</td>
                                <td><input type="radio" name="to-add" id="add-subject" value="add-subject" onclick="hide1()" ></td>
                                <td>Subject</td>
                                <td><input type="radio" name="to-add" id="add-branch" value="add-branch" onclick="hide2()"></td>
                                <td>Branch</td>
                                
                            </tr>
                        </table>
                
                        <form form action="uploadsub-exp.php" method="post" enctype="multipart/form-data" id="add-sub">
                            <select style="margin-bottom:20px; width: 70%; height:30px;" onchange="fetch_brnc(this.value); " name="add-majj" required="required">
                                <option hidden selected>select stream </option>
                                <option>Engineering</option>
                                <option>Medical</option>
                                <option>Law</option>
                                <option>Business & Marketing</option>
                            </select>
                            <br>
                            
                            <select id="add-brnc" name="add-brnc" onchange="fetch_subb(this.value)" style="margin-bottom:20px; width: 70%; height:30px;" required="required">
                        <option hidden selected>Select branch</option>
                     </select>

                            <br>
                              <select id="add-subb" name="add-subb" style="margin-bottom:20px; width: 70%; height:30px;" required="required">
                        <option hidden selected>Select subject</option>
                     </select>

                            <br>
                             <input type="text" name="add-tpic" id="add-tpic" style="margin-bottom:20px; width: 70%; height:30px;" placeholder="Topic" required="required">
                            <br>
                            <input type="submit" name="" style="margin-bottom:20px;margin-top: 20px;" onclick="check();">
                            <br>
                        </form>


                        <form form action="uploadsub-exp.php" method="post" enctype="multipart/form-data" id="add-sub1"  hidden>
                            <select style="margin-bottom:20px; width: 70%; height:30px;" onchange="fetch_brnc1(this.value); " name="add-majj1">
                                <option hidden selected>select stream </option>
                                <option>Engineering</option>
                                <option>Medical</option>
                                <option>Law</option>
                                <option>Business & Marketing</option>
                            </select>
                            <br>
                            
                            <select id="add-brnc1" name="add-brnc1" onchange="fetch_subb(this.value)" style="margin-bottom:17px; width: 70%; height:30px;">
                        <option hidden selected>Select branch</option>
                     </select>

                            <br>
                                 <input type="text" name="add-subb1" id="add-subb1" style="margin-bottom:1px; width: 70%; height:30px;" placeholder="subject" required="required">
                            <br>

                            <br>
                             <input type="text" name="add-tpic1" id="add-tpic1" style="margin-bottom:15px; width: 70%; height:30px;" placeholder="Topic" required="required">
                            <br>
                            <input type="submit" name="" style="margin-bottom:20px;margin-top: 20px;">
                            <br>
                        </form>



                        <form form action="uploadsub-exp.php" method="post" enctype="multipart/form-data" id="add-sub2" hidden>
                            <select style="margin-bottom:20px; width: 70%; height:30px;" onchange="fetch_brnc1(this.value); " name="add-majj2">
                                <option hidden selected>select stream </option>
                                <option>Engineering</option>
                                <option>Medical</option>
                                <option>Law</option>
                                <option>Business & Marketing</option>
                            </select>
                            <br>
                            <input type="text" name="add-brnc2" id="add-brnc2" style="margin-bottom:15px; width: 70%; height:30px;" placeholder="branch" required="required">
                            

                            <br>
                                 <input type="text" name="add-subb2" id="add-subb2" style="margin-bottom:1px; width: 70%; height:30px;" placeholder="subject" required="required">
                            <br>

                            <br>
                             <input type="text" name="add-tpic2" id="add-tpic2" style="margin-bottom:15px; width: 70%; height:30px;" placeholder="Topic" required="required">
                            <br>
                            <input type="submit" name="" style="margin-bottom:20px;margin-top: 20px;">
                            <br>
                        </form>


                        
                    </td>
                </tr>
                <tr>
                    <td colspan="4" align="center"><b>Total Number of</b></td>
                </tr>
                <tr>
                    <td align="center"><b>Expert</b></td>
                    <td align="center"><b>Student</td>
                    <td align="center"><b>Visitors</b></td>
                </tr>
                <tr>
                    
                    <td align="center"><?php
                    include "connectdb.php";
$find2=mysqli_query($con,"SELECT COUNT(*) as total FROM `users` WHERE `type`='expert'");
while($arr=mysqli_fetch_assoc($find2))
                    {echo $arr["total"];}
?></td>
                    <td align="center"><?php
                    include "connectdb.php";
$find2=mysqli_query($con,"SELECT COUNT(*) as total FROM `users` WHERE `type`='student'");
while($arr=mysqli_fetch_assoc($find2))
                    {echo $arr["total"];}
?></td>
                    <td align="center"><?php
$myfile = fopen("counter.txt", "r") or die("Unable to open file!");
echo fread($myfile,filesize("counter.txt"));
fclose($myfile);
?></td>
                </tr>
                <tr>
                   
                </tr>

            </table>



         </div>
         <div id="tab4"><h2 class="header">Add notes</h2>
           <input type="button" name="insert-notes" id="insert-note" value="insert notes" onclick="inst_notes()" style="background-color: #137BAE; height: 50px; width: 45%; border-radius: 7px; margin-left: 20px;" >
            <input type="button" name="insert-example" id="insert-example" value="insert example" onclick="inst_example()" style="background-color: #137BAE; height: 50px; width: 45%; border-radius: 7px; ">
           <form form action="upload-exp.php" method="post" enctype="multipart/form-data" id="add-notes" style="margin-top: 13px; margin-left: 7%;margin-bottom: 40px; width: 80%; padding-left: 25px;" >
                                <select   name="major" onchange="fetch_branch(this.value);" style="height: 25px; width: 23%;">
                      <option hidden selected>Select major</option>
                    <?php
                    $find=mysqli_query($con,"SELECT DISTINCT `major` FROM `subject`");
                     while($row=mysqli_fetch_array($find))
                     {
                      echo "<option>".$row['major']."</option>";
                     }
                    ?>
                    </select>
                    <select id="branch" name="branch" onchange="fetch_subject(this.value);" style="height: 25px; width: 23%;">
                        <option hidden selected>Select branch</option>
                     </select>
                      <select id="subbject" name="subbject" onchange="fetch_topic(this.value);" style="height: 25px; width: 23%;">
                        <option hidden selected>Select subject</option>
                     </select>
                     <select id="toppic" name="toppic" style="height: 25px; width: 23%;">
                        <option hidden selected>Select topic</option>
                     </select><br>
                     
                     <textarea name="notes" required id="notes" placeholder="enter notes here" style="margin-top: 10px;margin-bottom: 10px; height: 120px;width: 93%;"></textarea>
                     <br>
                    <input type="text" required id="source" name="source" placeholder="source" style="height: 25px; width: 94%">
                    <!--set by to username from session-->
                    <input type="hidden" value="<?php echo $_SESSION["first_name"]; ?>" id="by" required name="by" placeholder="by" style="height: 25px; width: 46%">
                    <br>
                    <table >
                        <tr><td>
                    <input type="checkbox" name="img" id="img" onclick="showhide()" value="imagepresent">
                    </td><td><p>insert image</p>
                    </td></tr>
                    </table>
                    <input type="hidden" name="fileToUpload" id="fileToUpload" style="margin-bottom: 15px;"><br>
                    <input type="submit" value="upload-notes" name="uploadnotes" style="margin-left: 40%;height: 50px; width: 23%; border-radius: 5px; background-color: #137BAE; ">
            </form>

            <form form action="uploadexample-exp.php" method="post" enctype="multipart/form-data" id="addexmp" hidden="hidden" style="margin-top: 13px; margin-left: 7%;margin-bottom: 40px; width: 80%; padding-left: 25px;"  >
                                <select   name="major-exmp" onchange="fetch_branch_exmp(this.value);">
                      <option hidden selected>Select major</option>
                    <?php
                    $find=mysqli_query($con,"SELECT DISTINCT `major` FROM `subject`");
                     while($row=mysqli_fetch_array($find))
                     {
                      echo "<option>".$row['major']."</option>";
                     }
                    ?>
                    </select>

                    <select id="branch-exmp" name="branch-exmp" onchange="fetch_subject_exmp(this.value);">
                        <option hidden selected>Select branch</option>
                     </select>
                      <select id="subbject-exmp" name="subbject-exmp" onchange="fetch_topic_exmp(this.value);">
                        <option hidden selected>Select subject</option>
                     </select>
                     <select id="toppic-exmp" name="toppic-exmp" >
                        <option hidden selected>Select topic</option>
                     </select>
                     <br><br>
                     <textarea name="ex-ques" id="ex-ques" placeholder="enter question here" style="height: 120px;width:673px;"></textarea><br><br>
                     <textarea name="ex-sol" id="ex-sol" placeholder="enter solution here" style="height: 120px;width: 673px;"></textarea>
                     <br>
                     <table >
                        <tr><td>
                    <input type="checkbox" name="img1" id="img1" onclick="showhide1()">
                    </td><td><p>insert image</p>
                    </td></tr>
                    </table>
                    <input type="hidden" name="fileToUpload1" id="fileToUpload1">
                    <br>
                    <input type="submit" value="upload example" name="uploadexmp" style="margin-left: 40%;height: 50px; width: 23%; border-radius: 5px; background-color: #137BAE; ">
                     <br>
                 </form>



         </div>
         <div id="tab5"><h2 class="header">add videos</h2>
           <form form action="uploadvideo-exp.php" method="post" enctype="multipart/form-data" id="addvid" style="margin-top: 13px; margin-left: 7%;margin-bottom: 40px; width: 80%; padding-left: 25px;" >
                                <select   name="major-vid" onchange="fetch_branch_vid(this.value);">
                      <option hidden selected>Select major</option>
                    <?php
                    $find=mysqli_query($con,"SELECT DISTINCT `major` FROM `subject`");
                     while($row=mysqli_fetch_array($find))
                     {
                      echo "<option>".$row['major']."</option>";
                     }
                    ?>
                    </select>

                    <select id="branch-vid" name="branch-vid" onchange="fetch_subject_vid(this.value);">
                        <option hidden selected>Select branch</option>
                     </select>
                      <select id="subbject-vid" name="subbject-vid" onchange="fetch_topic_vid(this.value);">
                        <option hidden selected>Select subject</option>
                     </select>
                     <select id="toppic-vid" name="toppic-vid" >
                        <option hidden selected>Select topic</option>
                     </select><br><br>
                     <input type="text" required="required" name="vid-name" id="vid-name" placeholder="video name" style="height: 25px;width: 93%">
                     <br>


                     <table width="70%" >
                                <td><input type="radio" name="type" value="upload" checked onclick="upl()" style="height: 17px;width: 17px;"></td>
                                <td><p style=" text-align:left;">upload a video</p></td>
                                <td><input type="radio" name="type" value="youtube" onclick="yout()" style="height: 17px;width: 17px;"></td>
                                <td><p style=" text-align: left;">insert youtube link</p></td>
                              </table>
                              <input type="text" name="addurl" placeholder="youtube url" id="youtube" hidden="hidden" style="height: 25px;width: 93%">
                              <input type="file" name="uploadvideo" id="uploadvideo">
                              <br>
                              <br>
                              <input type="submit" value="upload-video" name="upload-video" style="margin-left: 40%;height: 50px; width: 23%; border-radius: 5px; background-color: #137BAE; ">
                              <script type="text/javascript">
                                  function upl()
                                    {
                                        document.getElementById("youtube").hidden='hidden'; 
                                        document.getElementById("uploadvideo").hidden='';
                                         
                                            
                                    }

                                    function yout()
                                    {
                                           document.getElementById("uploadvideo").hidden='hidden'; 
                                        document.getElementById("youtube").hidden='';
                                    }
                              </script>



                </form>

         </div>
         <div id="tab6"><h2 class="header">Add quiz questions</h2>
            <br>
            <form action="uploadquiz-exp.php" method="post" enctype="multipart/form-data" id="addquiz" style="margin-top: 13px; margin-left: 7%;margin-bottom: 40px; width: 80%; padding-left: 25px;" >
                    <select name="major-quiz" onchange="fetch_branch_quiz(this.value);">
                      <option hidden selected>Select major</option>
                    <?php
                    $find=mysqli_query($con,"SELECT DISTINCT `major` FROM `subject`");
                     while($row=mysqli_fetch_array($find))
                     {
                      echo "<option>".$row['major']."</option>";
                     }
                    ?>
                    </select>

                    <select id="brranch-quiz" name="brranch-quiz" onchange="fetch_subject_quiz(this.value);">
                        <option hidden selected>Select branch</option>
                     </select>
                      <select id="subbject-quiz" name="subbject-quiz" onchange="fetch_topic_quiz(this.value);">
                        <option hidden selected>Select subject</option>
                     </select> 
                      <select id="toppic-quiz" name="toppic-quiz">
                        <option hidden selected>Select topic</option>
                     </select>
                     <br>
                     <textarea name="qz-ques" id="qz-ques" placeholder="enter question here" style="height: 100px;width: 93%; margin-top: 10px; margin-bottom: 10px;"></textarea><br>
                     <textarea name="qz-op1" id="qz-op1" placeholder="enter option a" style="height: 85px;width: 215px;"></textarea>
                     <textarea name="qz-op2" id="qz-op2" placeholder="enter option b" style="height: 85px;width: 215px;"></textarea>
                     <textarea name="qz-op3" id="qz-op3" placeholder="enter option c" style="height: 85px;width: 215px;"></textarea>
                     <br>

                     <select name="correct" style="margin-top: 10px">
                        <option selected hidden> correct option</option>
                         <option>a</option>
                         <option>b</option>
                         <option>c</option>
                     </select>
                     <br><br>
                     <input type="submit" value="insert question" name="insert-ques" style="margin-left: 40%;height: 50px; width: 23%; border-radius: 5px; background-color: #137BAE; ">

                </form>
            


         </div>    
    </div>
  
 
</div>
<script src="adminjs.js"></script
<script src="simpl.js"></script>
<script src="datanotes.js"></script>
<script src="ajax.js"></script>
<script type="text/javascript">
function fetch_brnc(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_major:val
 },
 success: function (response) {
  document.getElementById("add-brnc").innerHTML=response; 
 }
 });
}

function fetch_subb(val)
{
    
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_branch:val
 },
 success: function (response) {
  document.getElementById("add-subb").innerHTML=response; 
 }
 });
}

function fetch_brnc1(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_major:val
 },
 success: function (response) {
  document.getElementById("add-brnc1").innerHTML=response; 
 }
 });
}

function hide() {
    document.getElementById("add-sub2").hidden='hidden';
    document.getElementById("add-sub1").hidden='hidden';
    document.getElementById("add-sub").hidden=''; 
    // body...
}
function hide1() {
    document.getElementById("add-sub2").hidden='hidden';
    document.getElementById("add-sub").hidden='hidden';
    document.getElementById("add-sub1").hidden=''; 
    // body...
}
function hide2() {
    document.getElementById("add-sub").hidden='hidden';
    document.getElementById("add-sub1").hidden='hidden';
    document.getElementById("add-sub2").hidden=''; 
    // body...
}
function check() {
    //not req anymore
}
function inst_notes() {
    document.getElementById("add-notes").hidden='';
    document.getElementById("addexmp").hidden='hidden';
    // body...
}
function inst_example() {
    document.getElementById("add-notes").hidden='hidden';
    document.getElementById("addexmp").hidden='';
    // body...
}


</script>
</body>
</html>
 