<?php
 include "connectdb.php";
if (isset($_POST['img'])) {
$file_name=basename( $_FILES["fileToUpload"]["name"]);
$target_dir = "../uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}

// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
}

if (isset($_POST['uploadnotes'])) {
    $major=$_POST['major'];
    $branch=$_POST['branch'];
    $subject=$_POST['subbject'];
    $topic=$_POST['toppic'];
    $notes=$_POST['notes'];
    $source=$_POST['source'];
    $by=$_POST['by'];
    if (isset($_POST['img'])) {
        if ($uploadOk==1) {
            # code...
        mysqli_query($con,"INSERT INTO `notes` (`id`, `major`, `branch`, `subject`, `topic`, `notes`, `from_`, `by_`, `image`, `image_url`) VALUES (NULL, '$major', '$branch', '$subject', '$topic', '$notes', '$source', '$by', 'y', '$target_file')");
        header("Location:admin.php");
               }

    }
    else {
        mysqli_query($con,"INSERT INTO `notes` (`id`, `major`, `branch`, `subject`, `topic`, `notes`, `from_`, `by_`, `image`, `image_url`) VALUES (NULL, '$major', '$branch', '$subject', '$topic', '$notes', '$source', '$by', 'n', '')");
               
        header("Location:admin.php");
        # code...
    }
    

    # code...
}


if (isset($_POST['delete-notes'])) {
    $notes=$_POST['notes1'];
    mysqli_query($con,"DELETE FROM `notes` WHERE `notes`='$notes'");
               
        header("Location:admin.php");
        # code...
    }
    

    # code...



?>