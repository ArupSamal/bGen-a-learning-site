<?php
include "connectdb.php";
if (isset($_POST['add-admin'])) {
	$first=$_POST['first-name'];
	$last=$_POST['last-name'];
	$email=$_POST['e-mail'];
	$pass=$_POST['pass-word'];
	$type='admin';
	mysqli_query($con,"INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `password`, `type`) VALUES (NULL, '$first', '$last', '$email', '$pass', 'admin')");
	 header("Location:admin.php");
}
