<?php
$con=mysqli_connect('localhost','root','','project');
if (!$con) {
	die("failed");
	# code...
}
?>