
    
<?php
include "connectdb.php";
if (isset($_POST['img1'])) {
$file_name=basename( $_FILES["fileToUpload1"]["name"]);
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload1"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}

// Check file size
if ($_FILES["fileToUpload1"]["size"] > 500000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload1"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload1"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
}



    if (isset($_POST['uploadexmp'])) {
    $major=$_POST['major-exmp'];
    $branch=$_POST['branch-exmp'];
    $subject=$_POST['subbject-exmp'];
    $topic=$_POST['toppic-exmp'];
    $ques=$_POST['ex-ques'];
    $sol=$_POST['ex-sol'];
    if (isset($_POST['img1'])) {
        if ($uploadOk==1) {
            # code...
        mysqli_query($con,"INSERT INTO `examples` (`id`, `major`, `branch`, `subject`, `topic`, `question`, `solution`, `image`, `image_url`) VALUES (NULL, '$major', '$branch', '$subject', '$topic', '$ques', '$sol', 'y', '$target_file')");
        header("Location:admin.php");
               }

    }
    else {
        mysqli_query($con,"INSERT INTO `examples` (`id`, `major`, `branch`, `subject`, `topic`, `question`, `solution`, `image`, `image_url`) VALUES (NULL, '$major', '$branch', '$subject', '$topic', '$ques', '$sol', 'n', '')");
         header("Location:admin.php");
        
               
       
        # code...
    }

    

    # code...
}

if (isset($_POST['delexmp'])) {
    $exmp=$_POST['toppic-q-exmp1'];
    mysqli_query($con,"DELETE FROM `examples` WHERE `question`='$exmp'");
               
        header("Location:admin.php");
        # code...
    }
    

?>