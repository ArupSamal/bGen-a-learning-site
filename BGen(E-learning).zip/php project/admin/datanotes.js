function fetch_branch(val)
{

 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_major:val
 },
 success: function (response) {
  document.getElementById("branch").innerHTML=response; 
 }
 });
}



function fetch_subject(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_branch:val
 },
 success: function (response) {
  document.getElementById("subbject").innerHTML=response; 
 }
 });
}


function fetch_topic(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_subject:val
 },
 success: function (response) {
  document.getElementById("toppic").innerHTML=response; 
 }
 });
}
 


function showhide() {
    var x = document.getElementById("fileToUpload");
    if (x.type == "hidden") {
        x.type = "file";
    } else {
        x.type = "hidden";
    }
}


function fetch_branch1(val)
{

 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_major:val
 },
 success: function (response) {
  document.getElementById("branch1").innerHTML=response; 
 }
 });
}

function fetch_subject1(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_branch:val
 },
 success: function (response) {
  document.getElementById("subbject1").innerHTML=response; 
 }
 });
}



function fetch_topic1(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_subject:val
 },
 success: function (response) {
  document.getElementById("toppic1").innerHTML=response; 
 }
 });
}


function fetch_notes1(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_topic:val
 },
 success: function (response) {
  document.getElementById("notes1").innerHTML=response; 
 }
 });
}


//videos

function fetch_branch_vid(val)
{

 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_major:val
 },
 success: function (response) {
  document.getElementById("branch-vid").innerHTML=response; 
 }
 });
}



function fetch_subject_vid(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_branch:val
 },
 success: function (response) {
  document.getElementById("subbject-vid").innerHTML=response; 
 }
 });
}


function fetch_topic_vid(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_subject:val
 },
 success: function (response) {
  document.getElementById("toppic-vid").innerHTML=response; 
 }
 });
}

//video del


function fetch_branch_vid1(val)
{

 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_major:val
 },
 success: function (response) {
  document.getElementById("brranch-vid1").innerHTML=response; 
 }
 });
}



function fetch_subject_vid1(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_branch:val
 },
 success: function (response) {
  document.getElementById("subbject-vid1").innerHTML=response; 
 }
 });
}


function fetch_topic_vid1(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_subject:val
 },
 success: function (response) {
  document.getElementById("toppic-vid1").innerHTML=response; 
 }
 });
}

function fetch_vid_name(val)
{

 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_vtopic:val
 },
 success: function (response) {
  document.getElementById("vidname").innerHTML=response; 
 }
 });
}

function ins_vid()
{
    document.getElementById("delete-notes").hidden='hidden'; 
    document.getElementById("add-notes").hidden='';
     
        
}

function del_vid()
{
       document.getElementById("add-notes").hidden='hidden'; 
       document.getElementById("delete-notes").hidden='';
}


//example add
