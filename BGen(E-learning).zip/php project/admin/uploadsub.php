<?php
include "connectdb.php";
if (isset($_POST['add-majj'])) {
	$maj=$_POST['add-majj'];
	$brn=$_POST['add-brnc'];
	$sub=$_POST['add-subb'];
	$top=$_POST['add-tpic'];
	mysqli_query($con,"INSERT INTO `subject` (`id`, `major`, `branch`, `subject`, `topic`) VALUES (NULL, '$maj', '$brn', '$sub', '$top')");
       header("Location:admin.php");
	
}
if (isset($_POST['add-majj1'])) {
	$maj=$_POST['add-majj1'];
	$brn=$_POST['add-brnc1'];
	$sub=$_POST['add-subb1'];
	$top=$_POST['add-tpic1'];
	mysqli_query($con,"INSERT INTO `subject` (`id`, `major`, `branch`, `subject`, `topic`) VALUES (NULL, '$maj', '$brn', '$sub', '$top')");
       header("Location:admin.php");
	# code...
}
if (isset($_POST['add-majj2'])) {
	$maj=$_POST['add-majj2'];
	$brn=$_POST['add-brnc2'];
	$sub=$_POST['add-subb2'];
	$top=$_POST['add-tpic2'];
	mysqli_query($con,"INSERT INTO `subject` (`id`, `major`, `branch`, `subject`, `topic`) VALUES (NULL, '$maj', '$brn', '$sub', '$top')");
       header("Location:admin.php");
	# code...
}
?>
