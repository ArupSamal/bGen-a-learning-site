<?php
include "connectdb.php";
echo $_POST['type'];
if (isset($_POST['type'])) {
$file_name=basename( $_FILES["uploadvideo"]["name"]);
$target_dir = "../uploads/";
$target_file = $target_dir . basename($_FILES["uploadvideo"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}

// Check file size
if ($_FILES["uploadvideo"]["size"] > 500000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["uploadvideo"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["uploadvideo"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
}



    if (isset($_POST['upload-video'])) {
    $major=$_POST['major-vid'];
    $branch=$_POST['branch-vid'];
    $subject=$_POST['subbject-vid'];
    $topic=$_POST['toppic-vid'];
    $name=$_POST['vid-name'];
    if (isset($_POST['type'])=='upload') {
        if ($uploadOk==1) {

            # code...
        mysqli_query($con,"INSERT INTO `videos` (`id`, `major`, `branch`, `subject`, `topic`, `upvotes`, `downvotes`, `url`, `name`, `views`, `from_`) VALUES (NULL, '$major', '$branch', '$subject', '$topic', '0', '0', '$target_file', '$name', '0', 'local')");
        header("Location:admin.php");
               }

    }
    if (isset($_POST['type'])=='youtube')  {
        echo "<br> test url";
        $url=$_POST['addurl'];
        mysqli_query($con,"INSERT INTO `videos` (`id`, `major`, `branch`, `subject`, `topic`, `upvotes`, `downvotes`, `url`, `name`, `views`, `from_`) VALUES (NULL, '$major', '$branch', '$subject', '$topic', '0', '0', '$url', '$name', '0', 'youtube')");
         header("Location:admin.php");
        
               
       
        # code...
    }

    

    # code...
}

if (isset($_POST['delete-video'])) {
    $name=$_POST['vdname'];
    mysqli_query($con,"DELETE FROM `videos` WHERE `name`='$name'");
    header("Location:admin.php");           
        # code...
    }
    

?>