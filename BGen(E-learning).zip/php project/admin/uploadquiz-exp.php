<?php
include "connectdb.php";
if (isset($_POST['insert-ques'])) {
    $major=$_POST['major-quiz'];
    $branch=$_POST['brranch-quiz'];
    $subject=$_POST['subbject-quiz'];
    $topic=$_POST['toppic-quiz'];
    $ques=$_POST['qz-ques'];
    $op1=$_POST['qz-op1'];
    $op2=$_POST['qz-op2'];
    $op3=$_POST['qz-op3'];
    $correct=$_POST['correct'];
   
            # code...
        mysqli_query($con,"INSERT INTO `quiz` (`id`, `major`, `branch`, `subject`, `topic`, `question`, `op1`, `op2`, `op3`, `corr_opn`) VALUES (NULL, '$major', '$branch', '$subject', '$topic', '$ques', '$op1', '$op2', '$op3', '$correct')");
       header("Location:expert.php");
               

    # code...
}

if (isset($_POST['delete-ques'])) {
    $ques=$_POST['ques'];
    mysqli_query($con,"DELETE FROM `quiz` WHERE `question`='$ques'");
    header("Location:expert.php");
        # code...
    }
    

?>