function showhide1() {
    var x = document.getElementById("fileToUpload1");
    if (x.type === "hidden") {
        x.type = "file";
    } else {
        x.type = "hidden";
    }
}

function fetch_branch_exmp(val)
{

 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_major:val
 },
 success: function (response) {
  document.getElementById("branch-exmp").innerHTML=response; 
 }
 });
}



function fetch_subject_exmp(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_branch:val
 },
 success: function (response) {
  document.getElementById("subbject-exmp").innerHTML=response; 
 }
 });
}


function fetch_topic_exmp(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_subject:val
 },
 success: function (response) {
  document.getElementById("toppic-exmp").innerHTML=response; 
 }
 });
}


function ins_vid()
{
    document.getElementById("delvid").hidden='hidden'; 
    document.getElementById("addvid").hidden='';
     
        
}

function del_vid()
{
       document.getElementById("addvid").hidden='hidden'; 
       document.getElementById("delvid").hidden='';
}

//del example

function fetch_branch_exmp1(val)
{

 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_major:val
 },
 success: function (response) {
  document.getElementById("branch-exmp1").innerHTML=response; 
 }
 });
}



function fetch_subject_exmp1(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_branch:val
 },
 success: function (response) {
  document.getElementById("subbject-exmp1").innerHTML=response; 
 }
 });
}


function fetch_topic_exmp1(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_subject:val
 },
 success: function (response) {
  document.getElementById("toppic-exmp1").innerHTML=response; 
 }
 });
}


function fetch_question_exmp1(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_top_ex:val
 },
 success: function (response) {
  document.getElementById("toppic-q-exmp1").innerHTML=response; 
 }
 });
}
function ins_example()
{
   
    document.getElementById("delexmp").hidden='hidden'; 
    document.getElementById("delete-notes").hidden='hidden'; 
    document.getElementById("add-notes").hidden='hidden'; 
     document.getElementById("addexmp").hidden='';      
}

function del_example()
{
       document.getElementById("addexmp").hidden='hidden'; 
    document.getElementById("delete-notes").hidden='hidden'; 
    document.getElementById("add-notes").hidden='hidden'; 
     document.getElementById("delexmp").hidden=''; 
}

function ins_notes()
{
   
    document.getElementById("delexmp").hidden='hidden'; 
    document.getElementById("delete-notes").hidden='hidden'; 
    document.getElementById("add-notes").hidden=''; 
     document.getElementById("addexmp").hidden='hidden';      
}

function del_notes()
{
       document.getElementById("addexmp").hidden='hidden'; 
    document.getElementById("delete-notes").hidden=''; 
    document.getElementById("add-notes").hidden='hidden'; 
     document.getElementById("delexmp").hidden='hidden'; 
}

//add quiz

function fetch_branch_quiz(val)
{

 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_major:val
 },
 success: function (response) {
  document.getElementById("brranch-quiz").innerHTML=response; 
 }
 });
}



function fetch_subject_quiz(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_branch:val
 },
 success: function (response) {
  document.getElementById("subbject-quiz").innerHTML=response; 
 }
 });
}


function fetch_topic_quiz(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_subject:val
 },
 success: function (response) {
  document.getElementById("toppic-quiz").innerHTML=response; 
 }
 });
}
//del quiz question

function fetch_branch_quiz1(val)
{

 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_major:val
 },
 success: function (response) {
  document.getElementById("brranch-quiz1").innerHTML=response; 
 }
 });
}



function fetch_subject_quiz1(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_branch:val
 },
 success: function (response) {
  document.getElementById("subbject-quiz1").innerHTML=response; 
 }
 });
}


function fetch_topic_quiz1(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_subject:val
 },
 success: function (response) {
  document.getElementById("toppic-quiz1").innerHTML=response; 
 }
 });
}



function fetch_question_quiz1(val)
{
 $.ajax({
 type: 'post',
 url: 'sel-ajax.php',
 data: {
  get_quiz_ques:val
 },
 success: function (response) {
  document.getElementById("question-quiz1").innerHTML=response; 
 }
 });
}

function ins_quiz()
{
   
    document.getElementById("delquiz").hidden='hidden'; 
     document.getElementById("addquiz").hidden='';      
}

function del_quiz()
{
       document.getElementById("addquiz").hidden='hidden'; 
    document.getElementById("delquiz").hidden=''; 
}

//admin



