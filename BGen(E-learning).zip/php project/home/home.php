<?php 
session_start();
if(isset($_SESSION["first_name"]))
{
$first_name = $_SESSION["first_name"];
 echo "WELCOME";
echo $first_name;
echo "&nbsp you are at homepage";
}
  ?>
<?php 
include_once('connectdb.php');
if(isset($_REQUEST["addques"]))
{
	$ques=$_REQUEST["ques"];
	$op1=$_REQUEST["op1"];
	$op2=$_REQUEST["op2"];
	$op3=$_REQUEST["op3"];
	$corrr=$_REQUEST["corrr"];
	$usr = $_SESSION["first_name"];
	$sql= "INSERT INTO `pending_ques` (`id`, `user`, `question`, `op1`, `op2`, `op3`, `correct`) VALUES (NULL, '$usr', '$ques', '$op1', '$op2', '$op3', '$corrr')";
		$res= mysqli_query($con,$sql) or die("Failed".mysqli_error());

}
 ?>




  <form>
  	<input type="text" name="ques">
  	<input type="text" name="op1">
  	<input type="text" name="op2">
  	<input type="text" name="op3">
  	<select name="corrr">
  		<option selected="selected" hidden="hidden"> choose correct option</option>
  		<option>a</option>
  		<option>b</option>
  		<option>c</option>
  	</select>
  	<input type="submit" name="addques">
  </form>

  <a href="logout.php">logout</a>
