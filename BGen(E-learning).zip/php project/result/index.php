<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
		<meta name="viewport" content="width=device-width, initial-scale=1"> 
		<title>result</title>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

		<link rel="stylesheet" type="text/css" href="css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="css/demo.css" />
		<link rel="stylesheet" type="text/css" href="css/tabs.css" />
		<link rel="stylesheet" type="text/css" href="css/tabstyles.css" />
		<link rel="stylesheet" type="text/css" href="css/navstyle.css" />

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="../landing/Bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../landing/main.css">
<link rel="stylesheet" type="text/css" href="../landing/test.css">
  


  		<script src="js/modernizr.custom.js"></script>
	</head>
	<body>
		<div id='main'>
		<svg class="hidden">
			<defs>
				<path id="tabsh" d="M80,60C34,53.5,64.417,0,0,0v60H80z"/>
			</defs>
		</svg>
		
			
			<header>
				<nav class="navbar navbar-inverse">
  <div class="container-fluid" >
    <div class="navbar-header" >
      
      <a  href="../landing/index.php"><img src="bgen.png" height=43 width="130" style="margin-right: 20px;" ></a>
    </div>
    <ul class="nav navbar-nav">

      <li><a href="../landing/index.php"><span class="glyphicon glyphicon glyphicon-home" >&nbspHome</a></li>
      	<!--<li><a href=""><span class="glyphicon glyphicon glyphicon-list" >&nbspBrowse-Cources</a></li>!-->

      
      
     
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <?php
      if(isset($_SESSION["type"]))
        {
          $typ=$_SESSION["type"];
          if ($typ=="admin") {
            echo '<li> <a href="../admin/admin.php">
          <span class="glyphicon glyphicon glyphicon-cog"></span>Admin panel
        </a></li>';
            # code...
          }
          if ($typ=="expert") {
            echo '<li> <a href="../admin/expert.php">
          <span class="glyphicon glyphicon glyphicon-cog"></span>Expert panel
        </a></li>';
            # code...
          }
          
        }
       ?>
       <li><a href="#"><span class="glyphicon glyphicon glyphicon-search" onclick="openSearch()" >&nbspSearch-Topic</a></li>
     <li><a href="#" >About us  </a></li>
      <li ><a href="#" >contact us</a></li>
      <?php 
      if(isset($_SESSION["first_name"]))
        {
          $f_name=$_SESSION["first_name"];
        echo  '<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">welcome '.$f_name.'&nbsp&nbsp  <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li> <a href="logout.php">
          <span class="glyphicon glyphicon glyphicon-off"></span>&nbsplogout&nbsp&nbsp
        </a></li>
        </ul> ';
          
        }
        else
        {

          echo '<li><a href="../login signup/testdbc.php"><span class="glyphicon glyphicon-user" ></span> Sign Up/login&nbsp&nbsp</a></li>';
        }
      ?>
      
    </ul>
  </nav>
				<div id="myOverlay" class="overlay" style="height: 450px;">
  <span class="closebtn" onclick="closeSearch()" title="Close Overlay">×</span>
  <div class="overlay-content">
    <form  >
      <input type="text" placeholder="Search.." name="search-item">
      <button type="submit" name="search" ><i class="fa fa-search"></i></button>
    </form>
  </div>
</div>


<script>
function openSearch() {
    document.getElementById("myOverlay").style.display = "block";
    document.getElementById("search_btn").hidden = "hidden";

}

function closeSearch() {
    document.getElementById("myOverlay").style.display = "none";
     document.getElementById("search_btn").hidden = "";
}
</script>

			</header>

				
         <!--<div class="rlogin"><a href="#">Login</a> </div>-->
<!--   navigation Start -->

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <?php
  if(isset($_REQUEST["search"])||isset($_POST["search"]))
  {
  	include "connectdb.php";
	$topic=$_REQUEST["search-item"];
	$sub=0;
	
	$find=mysqli_query($con,"SELECT DISTINCT `subject` FROM `subject` WHERE topic ='$topic'");
	while($row0=mysqli_fetch_array($find))
	{
		$sub=$row0['subject'];
		echo '<p style="font-size:30px;"><b>'.$sub.'</b></p>';

	}


  	$find1=mysqli_query($con,"SELECT DISTINCT `topic` FROM `subject` WHERE subject ='$sub'");
                      while($row1=mysqli_fetch_array($find1))
                     {
                      $top=$row1['topic'];
                      echo '<div align="left" style="padding-left: 15px; margin-top:-5px;">
<a href="../result/index.php?search-item='.$top.'&search=sh"><li>'.$top.'</li></a>
</div>';
                     }
                     if ($sub==0) {
                     	echo "oops result not found";
                     	# code...
                     }

  }
  else
  {
  	echo "oops result not found";
  }
?>
</div>

<span class="navbotton" style="font-size:30px;cursor:pointer; position: absolute;
  top: 50%;
  left: 0%;
  transform: translateY(-50%);background: rgba(#27ae60, .1);
      border-color: #1e90ff;
      color: #1e90ff;

       
     " onclick="openNav()">&#9776; </span>

<!--   navigation End-->


			 
			<section>
				<div class="tabs tabs-style-bar">
					<nav>
						<!--   logo BOTTON-->
						






						<!--   HOME BOTTON-->
						
						<ul>

							<li><a href="#section-bar-1" class="icon icon-list"><span>Notes</span></a></li>
							<li><a href="#section-bar-2" class="icon icon-display"><span>Videos</span></a></li>
							<li><a href="#section-bar-3" class="icon icon-box"><span>Example</span></a></li>
							<li><a href="#section-bar-4" class="icon icon-upload"><span>Quiz</span></a></li>
							
						</ul>

						

					</nav>
					<div class="content-wrap"   >
						<section id="section-bar-1">
							<div style="height: 100%;width: 100%; background-color: rgba(0,0,0,0.1); min-height: 500px;">
								<?php
  if(isset($_REQUEST["search"])||isset($_POST["search"]))
  {
  	include "connectdb.php";
	$topic=$_REQUEST["search-item"];
	$result1=mysqli_query($con,"SELECT * FROM `notes` WHERE topic='$topic'");
	echo '<div ><u><h2 align="center" style="margin-left: -60px; font-size:35px;" >'. $topic.'</h2></u><br><br>';

	while($arr1=mysqli_fetch_assoc($result1))
	{
		$notes=$arr1["notes"];
		$image=$arr1["image"];
		$from=$arr1["from_"];


		echo '<div >';
		if ($image=='y') {
			$urrl=$arr1["image_url"];
			echo '<h3  style="margin-left: ; font-size: 20px; color: black; align: justify;"><img src="'.$urrl.'" width="250" height="200" style="float:right;">'. $notes .'</h3> <br>';

			# code...
		}
		else
		{
		echo '<h3  style="margin-left: ; font-size: 20px; color: black; align: justify;">'. $notes .'</h3> <br>';
		}
		echo '<h2 align="right" style ="margin-top:-20px;">src-'. $from.'</h2></div><br><br>';
		

	}
}
	?>
								
								
							</div>
						</section>
						<section id="section-bar-2">
							<div style="height: 100%;width: 100%; background-color: rgba(0,0,0,0.1); min-height: 500px;">
								<?php
  if(isset($_REQUEST["search"])||isset($_POST["search"]))
  {
  	include "connectdb.php";
	$topic=$_REQUEST["search-item"];
	echo '<div ><u><h2 align="center" style="margin-left: -60x; font-size:35px;" >'. $topic.'</h2></u>';
	$result2=mysqli_query($con,"SELECT * FROM `videos` WHERE topic='$topic'");

	while($arr=mysqli_fetch_assoc($result2))
	{
		$frm=$arr["from_"];
		$nam=$arr["name"];
		if ($frm=="youtube") {
			echo '<h2 align="left" style="margin-left: 80px; font-size:35px;" >'. $nam.'</h2></u>';
			$url=$arr["url"];
			$str=substr($url,32);
			echo '<iframe width="80%" height="500" src="https://www.youtube.com/embed/'.$str.'" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>';
			# code...
			
		}
		else
		{
			echo '<h2 align="left" style="margin-left: 80px; font-size:35px;" >'. $nam.'</h2></u>';
		$url=$arr["url"];
		echo '<video width="80%" controls>
  <source src="'.$url.'" type="video/mp4">
 </video><br><br><br><br>
';}
		
	}
}
	?>
								
								
							</div>

						</section>
						<section id="section-bar-3">
							<div style="height: 100%;width: 100%; background-color: rgba(0,0,0,0.1); min-height: 500px;">
								<?php
  if(isset($_REQUEST["search"])||isset($_POST["search"]))
  {
  	include "connectdb.php";
	$topic=$_REQUEST["search-item"];
	$result1=mysqli_query($con,"SELECT * FROM `examples` WHERE topic='$topic'");
	echo '<div ><u><h2 align="center" style="margin-left: -60px; font-size:35px;" >'. $topic.'</h2></u><br>';
	while($arr1=mysqli_fetch_assoc($result1))
	{
		$ques=$arr1["question"];
		$sol=$arr1["solution"];
		$image=$arr1["image"];
		


		echo '<div ><h2 align="left" style="margin-left: 40px; font-size:35px;" >'. $ques.'</h2>';
		if ($image=='y') {
			$urrl=$arr1["image_url"];
			echo '<h3  style="margin-left: ; font-size: 20px; color: black; align: justify;"><img src="'.$urrl.'" width="250" height="200" style="float:right;">'. $sol .'</h3> <br>';

			# code...
		}
		else
		{
		echo '<h3  style="margin-left: ; font-size: 20px; color: black; align: justify;">'. $sol .'</h3> <br>';
		}
		

	}
}
	?>
								
								
							</div>
						</section>
						<section id="section-bar-4"><div style="height: 100%;width: 100%; background-color: rgba(0,0,0,0.1); min-height: 500px;">
							<form action="res.php" method="post" id="quiz_res" target="_blank" style="margin-left: 100px; margin-right: 50px;font-size: 7px;">
								<input type="hidden" name="tp" value="<?php echo $topic; ?>">
	

	<?php
	
	$i=1;

	echo '<div ><u><h2 align="center" style="margin-left: -60px; font-size:35px;" >'. $topic.'</h2></u><br><br>';
          $find=mysqli_query($con,"SELECT * FROM `quiz` WHERE `topic`='$topic'");
          while($row=mysqli_fetch_array($find))
                 {
                 	$qu=$i.".".$row['question'];
                     echo '<h1 style="color:black; margin-left: -50px; text-align:left;">Q'.$qu.'</h1>';
                     
                      $op1=$row['op1'];
                      $op2=$row['op2'];
                      $op3=$row['op3'];
                      echo '<table width="100%" style="margin-left: 50px; margin-right: 50px; " >
								<tr>
                                <td style="width: 20px"><input type="radio" name="q'.$i.'" value="a"></td>
                                <td><h3 style=" text-align:left; color:black; ">'.$op1.'</h3></td>
                                </tr>
                                <br>
                                <tr>
                                <td><input type="radio" name="q'.$i.'" value="b"></td>
                                <td><h3 style=" text-align:left; color:black;">'.$op2.'</h3></td>
                                </tr>
                                <tr>
                                <td><input type="radio" name="q'.$i.'" value="c"></td>
                                <td><h3 style=" text-align:left; color:black;">'.$op3.'</h3></td>
                                </tr>
                              </table>';
                              $i=$i+1;
                      
                 }
                 
                              
    ?>
    <input type="submit" name="submit-quiz" style="margin-left: 7% ;height:30px ;width:150px;font-size: 16px;  ">
</form>
							</div>
						</section>
						
					</div><!-- /content -->
				</div><!-- /tabs -->
			</section>
			
					</div><!-- /container -->
		<script src="js/cbpFWTabs.js"></script>
		<script>
			(function() {

				[].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
					new CBPFWTabs( el );
				});

			})();
		</script>
		<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
	</div></body>
</html>