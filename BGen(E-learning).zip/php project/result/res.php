<?php
session_start();
$name="Guest";
if(isset($_SESSION["first_name"]))
{
  $name=$_SESSION["first_name"];
  # code...
}
$topic=$_POST['tp'];
 include "connectdb.php";
 $find0=mysqli_query($con,"SELECT COUNT(*) as tot FROM `quiz` WHERE topic='$topic'");
 $row=mysqli_fetch_array($find0);
 $tq=$row['tot'];
 






 if (isset($_POST['submit-quiz'])) {
 	# code...
  
 //total number of questions
 for ($i=1; $i <=$tq ; $i++) { 
 if (isset($_POST['q'.$i])) 
{ 
 		$result[$i] = $_POST['q'.$i] ;
}
else
{
	$result[$i] = 'null' ;
}


 }
  $find=mysqli_query($con,"SELECT * FROM `quiz` WHERE `topic`='$topic'");
  $j=1;
  $correct=0;
  $incorrect=0;
  $unanswered=0;
          while($row=mysqli_fetch_array($find))
                 {
                 	$x=$row['corr_opn'];
                 	if ($x===$result[$j]) {
                 		$correct=$correct+1;
                
                 	}
                 	else if ($result[$j]=='null') {
                 		$unanswered=$unanswered+1;
                
                 	}
                 	else{
                 		$incorrect=$incorrect+1;

                 	}
                 	$j=$j+1;
                 }
                 echo "<br>correct->".$correct;
                 echo "<br>incorrect->".$incorrect;
                 echo "<br>unanswered->".$unanswered;
}

 $find1=mysqli_query($con,"SELECT * FROM `subject` WHERE `topic`='$topic'");
 $row=mysqli_fetch_array($find1);
 $branch=$row['branch'];
  $subject=$row['subject'];
echo $branch;
echo $subject;
echo $topic;
echo $name;
$per=($correct/($tq))*100;
echo "<br>";
echo $per;




?>
 <table border="0px">
  <tr>
   <table align="left
   " border="1px" style="border-collapse: collapse;">
    <tr>
      <td><?php echo $name; ?></td>
      <td> <?php echo $branch; ?></td>
      
    </tr>
    <td> <?php echo $topic; ?></td>
    <td> <?php echo $tq; ?></td>
     
   </table>
  </tr>
  <tr>
    <table align="left
   " border="1px" style="border-collapse: collapse;">
    <tr>
      <td><?php echo $correct; ?></td>
      <td> <?php echo $incorrect; ?></td>
      
    </tr>
    <td> <?php echo $unanswered; ?></td>
    <td> <?php echo $per; ?></td>
     
   </table>
    
  </tr>
 </table>